#eru 
apt update
apt install -y openssh-server
service ssh start

#eru
addduser varda 

#login di varda
ssh varda@192.223.1.1
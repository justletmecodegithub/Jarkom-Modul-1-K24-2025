#melkor
ping 192.223.1.1 -c 100


#client
telnet 10.15.43.32 [route]
ping google.com -c 3
